package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Spinner spinner = findViewById(R.id.spinner);
        Button enter = findViewById(R.id.Enter);

        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selectedOption = (String) spinner.getSelectedItem();
                Intent intent;
                switch (selectedOption) {
                    case "Reduce Fat":
                        intent = new Intent(MainActivity3.this, MainActivity6.class);
                        break;
                    case "Increase Muscle":
                        intent = new Intent(MainActivity3.this, MainActivity8.class);
                        break;
                    case "Stay Fit":
                        intent = new Intent(MainActivity3.this, MainActivity7.class);
                        break;
                    default:
                        return;
                }
                startActivity(intent);
            }
        });
    }
}