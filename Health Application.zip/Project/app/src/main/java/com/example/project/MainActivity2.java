package com.example.project;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        EditText height = findViewById(R.id.height);
        EditText weight = findViewById(R.id.weight);
        Button calculate = findViewById(R.id.calculate);
        TextView result = findViewById(R.id.textView3);

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String height_num = height.getText().toString();
                String weight_num = weight.getText().toString();

                try {
                    double height = Double.parseDouble(height_num);
                    double weight = Double.parseDouble(weight_num);
                    double bmi = weight / ((height/100) * (height/100));

                    result.setText(String.format("Your BMI: %.2f", bmi));
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity2.this, "Invalid input", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
